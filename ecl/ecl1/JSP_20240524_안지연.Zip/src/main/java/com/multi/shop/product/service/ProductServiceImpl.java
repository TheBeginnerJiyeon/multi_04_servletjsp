package com.multi.shop.product.service;

import static com.multi.shop.common.Template.getSqlSession;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;

import com.multi.shop.board.model.dto.BoardDTO;
import com.multi.shop.product.model.dao.ProductDAO;
import com.multi.shop.product.model.dto.ProductDTO;

public class ProductServiceImpl implements ProductService{
	
	ProductDAO productDAO = new ProductDAO();
	

	@Override
	public ArrayList<ProductDTO> selectList() throws Exception {
		
		SqlSession sqlSession = getSqlSession();
		ArrayList<ProductDTO> list = productDAO.selectList(sqlSession);
		sqlSession.close();
		
		return list;
		
		
	}


	@Override
	public int insertBoard(ProductDTO productDTO) throws Exception {
		
		SqlSession sqlSession = getSqlSession();

		int result = productDAO.inserProduct(sqlSession, productDTO);
		
		
		if(result > 0) {
			System.out.println("상품 입력 성공...");
			sqlSession.commit();
			
			
		}else {
			System.out.println("상품 입력 실패....");
			sqlSession.rollback();
			throw new Exception();
		}
		sqlSession.close();
		
		return result;
		
		
	}


	@Override
	public ProductDTO selectProduct(int id) throws Exception {
		
		SqlSession sqlSession = getSqlSession();

		
		ProductDTO result = productDAO.selectProduct(sqlSession, id);
		
		
		sqlSession.close();
		
		return result;
		
		
		
	}
	
	
	
	
}
