package com.multi.shop.product.service;

import java.util.ArrayList;

import com.multi.shop.board.model.dto.BoardDTO;
import com.multi.shop.product.model.dto.ProductDTO;

public interface ProductService{

	ArrayList<ProductDTO> selectList() throws Exception;

	int insertBoard(ProductDTO productDTO) throws Exception;

	ProductDTO selectProduct(int id) throws Exception;
	
	
	
	
	// ctrl shift o : import

}
