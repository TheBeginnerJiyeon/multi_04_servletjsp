package com.multi.shop.product.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.multi.shop.member.model.dto.MemberDTO;
import com.multi.shop.product.model.dto.ProductDTO;
import com.multi.shop.product.service.ProductService;
import com.multi.shop.product.service.ProductServiceImpl;

/**
 * Servlet implementation class BoardInsertServlet
 */
@WebServlet("/product/insert")
public class ProductInsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private ProductService productService = new ProductServiceImpl();
	
	String path = "";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductInsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		

		request.getRequestDispatcher("/WEB-INF/views/product/insertform.jsp").forward(request, response);
		
		
		
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String name = request.getParameter("name");
		String content = request.getParameter("content");
		
		int price = Integer.parseInt(request.getParameter("price"));
		
		String companyId = request.getParameter("companyId");
		String img = request.getParameter("img");
		
		
		MemberDTO loginMemberDTO = (MemberDTO) request.getSession().getAttribute("loginMember");
		String createdPerson = loginMemberDTO.getId();
		
		
		ProductDTO productDTO = new ProductDTO();
		
		productDTO.setName(name);
		productDTO.setContent(content);
		productDTO.setPrice(price);
		productDTO.setCompanyId(companyId);
		productDTO.setImg(img);
		productDTO.setCreatedPerson(createdPerson);
		
		
		try {
			// result 따라 더 나누기. 성공하면 success로 가도롥..
			// path = "/WEB-INF/views/common/success.jsp"
			// request.setAttribute("successCode", "insertBoard");
			
			int result= productService.insertBoard(productDTO);
			
			path = "/product/list";
			
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			path = "/WEB-INF/views/common/errorPage.jsp";
			request.setAttribute("msg", "제품 입력 실패!");
		}
		
		
		request.getRequestDispatcher(path).forward(request, response);
		
		
	}

}
