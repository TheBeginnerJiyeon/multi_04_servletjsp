package com.multi.shop.product.model.dto;

import java.util.Date;

import com.multi.shop.company.model.dto.CompanyDTO;


public class ProductDTO {
	
	private int id;
	private String name;
	private String content;
	private int price;
	private String companyId;
	private String img;
	private Date createdDate;
	private String createdPerson;
	private Date modifiedDate;
	private String modifiedPerson;
	private String status;
	
	
	CompanyDTO company;


	public ProductDTO() {
		super();
	}


	public ProductDTO(int id, String name, String content, int price, String companyId, String img, Date createdDate,
			String createdPerson, Date modifiedDate, String modifiedPerson, String status, CompanyDTO company) {
		super();
		this.id = id;
		this.name = name;
		this.content = content;
		this.price = price;
		this.companyId = companyId;
		this.img = img;
		this.createdDate = createdDate;
		this.createdPerson = createdPerson;
		this.modifiedDate = modifiedDate;
		this.modifiedPerson = modifiedPerson;
		this.status = status;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getContent() {
		return content;
	}


	public void setContent(String content) {
		this.content = content;
	}


	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	public String getCompanyId() {
		return companyId;
	}


	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}


	public String getImg() {
		return img;
	}


	public void setImg(String img) {
		this.img = img;
	}


	public Date getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}


	public String getCreatedPerson() {
		return createdPerson;
	}


	public void setCreatedPerson(String createdPerson) {
		this.createdPerson = createdPerson;
	}


	public Date getModifiedDate() {
		return modifiedDate;
	}


	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}


	public String getModifiedPerson() {
		return modifiedPerson;
	}


	public void setModifiedPerson(String modifiedPerson) {
		this.modifiedPerson = modifiedPerson;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public CompanyDTO getCompany() {
		return company;
	}


	public void setCompany(CompanyDTO company) {
		this.company = company;
	}


	@Override
	public String toString() {
		return "ProductDTO [id=" + id + ", name=" + name + ", content=" + content + ", price=" + price + ", companyId="
				+ companyId + ", img=" + img + ", createdDate=" + createdDate + ", createdPerson=" + createdPerson
				+ ", modifiedDate=" + modifiedDate + ", modifiedPerson=" + modifiedPerson + ", status=" + status + "]";
	}
	
	
	
	





}
