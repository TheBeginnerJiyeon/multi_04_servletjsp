package com.multi.shop.product.model.dao;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;

import com.multi.shop.board.model.dto.BoardDTO;
import com.multi.shop.product.model.dto.ProductDTO;



public class ProductDAO { 
	
	


	public ProductDAO() {
		
	}
	
	public ArrayList<ProductDTO> selectList(SqlSession sqlSession) throws Exception{
		

		return (ArrayList) sqlSession.selectList("productMapper.selectList");
	}

	public int inserProduct(SqlSession sqlSession, ProductDTO productDTO) {
		
		
		return sqlSession.insert("productMapper.insertProduct", productDTO);
	}

	public ProductDTO selectProduct(SqlSession sqlSession, int id) {
		
		
		
		return sqlSession.selectOne("productMapper.selectProduct", id);
	}


}
